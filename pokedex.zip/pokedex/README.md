

<div align="center">
    <img height="400em" src="https://github.com/pedrotomazdev/pedrotomazdev.github.io/blob/main/img/site_demonster.gif?raw=true" alt="Nenzadex - Pokedex fan made">
</div>





<div align="center" style="display: flex;">
    <img height="210em"
        src="https://github.com/pedrotomazdev/pedrotomazdev.github.io/blob/main/img/pagespeed-desktop.png?raw=true" />
    <img height="210em"
        src="https://github.com/pedrotomazdev/pedrotomazdev.github.io/blob/main/img/pagespeed-mobile.png?raw=true" />
</div>
